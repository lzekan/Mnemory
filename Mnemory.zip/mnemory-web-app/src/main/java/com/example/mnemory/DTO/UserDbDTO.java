package com.example.mnemory.DTO;

import lombok.Builder;
import lombok.Getter;

@Getter
public class UserDbDTO {
    private String username;
    private String password;
    private String email;
}
