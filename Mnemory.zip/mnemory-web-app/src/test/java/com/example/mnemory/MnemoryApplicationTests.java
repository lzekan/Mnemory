package com.example.mnemory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MnemoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
